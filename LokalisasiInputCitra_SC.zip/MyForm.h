#pragma once
//Memasukkan pustaka yang dibutuhkan
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string>
#include "MyForm.h"
#include "Header.h"
#include <cmath>

#define utara		0
#define selatan		1
#define timur		2
#define barat		3
#define baris		0
#define kolom		1

using namespace cv;
using namespace std;

extern cv::Mat src, utara_, selatan_, timur_, barat_;
extern int dialogStatus;

//untuk filter
extern int iLowH[4];
extern int iHighH[4];

extern int iLowS[4];
extern int iHighS[4];

extern int iLowV[4];
extern int iHighV[4];

double jarakVertLing, jarakVertMob, jarakHorzLing, jarakHorzMob, posX, posY;
double centerMarkX, centerMarkY, centerImX, centerImY;

struct s_posisi
{
	int x[4];
	int y[4];
};

s_posisi posisi;


namespace LokalisasiInputCitra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  buttonOpenFile;
	private: System::Windows::Forms::PictureBox^  pictureBoxSrc;
	private: System::Windows::Forms::PictureBox^  pictureBoxUtara;
	private: System::Windows::Forms::PictureBox^  pictureBoxSelatan;
	private: System::Windows::Forms::PictureBox^  pictureBoxTimur;
	private: System::Windows::Forms::PictureBox^  pictureBoxBarat;





	private: System::Windows::Forms::Label^  labelUtara;
	private: System::Windows::Forms::Label^  labelTimur;
	private: System::Windows::Forms::Label^  labelBarat;




	private: System::Windows::Forms::Label^  labelSelatan;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog;
	private: System::Windows::Forms::NumericUpDown^  numericLHB;
	private: System::Windows::Forms::NumericUpDown^  numericHHB;



	private: System::Windows::Forms::Label^  labelLHB;
	private: System::Windows::Forms::Label^  labelHHB;
	private: System::Windows::Forms::NumericUpDown^  numericLSB;
	private: System::Windows::Forms::NumericUpDown^  numericHSB;
	private: System::Windows::Forms::NumericUpDown^  numericLVB;
	private: System::Windows::Forms::NumericUpDown^  numericHVB;










	private: System::Windows::Forms::Label^  labelLSB;
	private: System::Windows::Forms::Label^  labelHSB;
	private: System::Windows::Forms::Label^  labelLVB;
	private: System::Windows::Forms::Label^  labelHVB;
	private: System::Windows::Forms::NumericUpDown^  numericLHU;
	private: System::Windows::Forms::NumericUpDown^  numericHHU;
	private: System::Windows::Forms::NumericUpDown^  numericLSU;
	private: System::Windows::Forms::NumericUpDown^  numericHSU;
	private: System::Windows::Forms::NumericUpDown^  numericLVU;
	private: System::Windows::Forms::NumericUpDown^  numericHVU;






	private: System::Windows::Forms::Label^  labelLHU;
	private: System::Windows::Forms::Label^  labelHHU;
	private: System::Windows::Forms::Label^  labelLSU;
	private: System::Windows::Forms::Label^  labelHSU;
	private: System::Windows::Forms::Label^  labelLVU;
	private: System::Windows::Forms::Label^  labelHVU;
	private: System::Windows::Forms::NumericUpDown^  numericLHT;
	private: System::Windows::Forms::NumericUpDown^  numericHHT;
	private: System::Windows::Forms::NumericUpDown^  numericLST;
	private: System::Windows::Forms::NumericUpDown^  numericHST;
	private: System::Windows::Forms::NumericUpDown^  numericLVT;
	private: System::Windows::Forms::NumericUpDown^  numericHVT;
	private: System::Windows::Forms::NumericUpDown^  numericLHS;







	private: System::Windows::Forms::NumericUpDown^  numericHHS;

	private: System::Windows::Forms::NumericUpDown^  numericLSS;

	private: System::Windows::Forms::NumericUpDown^  numericHSS;

	private: System::Windows::Forms::NumericUpDown^  numericLVS;

private: System::Windows::Forms::NumericUpDown^  numericHVS;
private: System::Windows::Forms::Label^  labelLHT;
private: System::Windows::Forms::Label^  labelHHT;
private: System::Windows::Forms::Label^  labelLST;
private: System::Windows::Forms::Label^  labelHST;
private: System::Windows::Forms::Label^  labelLVT;
private: System::Windows::Forms::Label^  labelHVT;
private: System::Windows::Forms::Label^  labelLHS;
private: System::Windows::Forms::Label^  labelHHS;
private: System::Windows::Forms::Label^  labelLSS;
private: System::Windows::Forms::Label^  labelHSS;
private: System::Windows::Forms::Label^  labelLVS;
private: System::Windows::Forms::Label^  labelHVS;
private: System::Windows::Forms::Label^  labelX;
private: System::Windows::Forms::Label^  labelY;
private: System::Windows::Forms::Label^  labelPosX;
private: System::Windows::Forms::Label^  labelPosY;
private: System::Windows::Forms::Button^  buttonPos;
private: System::Windows::Forms::Label^  labelPosBaratY;

private: System::Windows::Forms::Label^  labelPosUtaraX;
private: System::Windows::Forms::Label^  labelPosSelatanY;



private: System::Windows::Forms::Label^  labelPosTimurY;

private: System::Windows::Forms::Label^  labelPosUtaraY;
private: System::Windows::Forms::Label^  labelUY;
private: System::Windows::Forms::Label^  labelUX;
private: System::Windows::Forms::Label^  labelPosBaratX;
private: System::Windows::Forms::Label^  labelBY;
private: System::Windows::Forms::Label^  labelBX;
private: System::Windows::Forms::Label^  labelPosTimurX;
private: System::Windows::Forms::Label^  labelTY;


private: System::Windows::Forms::Label^  labelTX;
private: System::Windows::Forms::Label^  labelPosSelatanX;
private: System::Windows::Forms::Label^  labelSY;
private: System::Windows::Forms::Label^  labelSX;
private: System::Windows::Forms::Label^  labelTengahX;
private: System::Windows::Forms::Label^  labelTengahY;
private: System::Windows::Forms::Label^  LTX;
private: System::Windows::Forms::Label^  LTY;
private: System::Windows::Forms::Label^  labelMarkX;
private: System::Windows::Forms::Label^  labelMarkY;
private: System::Windows::Forms::Label^  LMX;
private: System::Windows::Forms::Label^  LMY;
private: System::Windows::Forms::Label^  labelXcm;
private: System::Windows::Forms::Label^  labelYcm;
private: System::Windows::Forms::NumericUpDown^  numericScale;
private: System::Windows::Forms::Label^  cm1;
private: System::Windows::Forms::Label^  cm2;









































	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->buttonOpenFile = (gcnew System::Windows::Forms::Button());
			this->pictureBoxSrc = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBoxUtara = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBoxSelatan = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBoxTimur = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBoxBarat = (gcnew System::Windows::Forms::PictureBox());
			this->labelUtara = (gcnew System::Windows::Forms::Label());
			this->labelTimur = (gcnew System::Windows::Forms::Label());
			this->labelBarat = (gcnew System::Windows::Forms::Label());
			this->labelSelatan = (gcnew System::Windows::Forms::Label());
			this->openFileDialog = (gcnew System::Windows::Forms::OpenFileDialog());
			this->numericLHB = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHHB = (gcnew System::Windows::Forms::NumericUpDown());
			this->labelLHB = (gcnew System::Windows::Forms::Label());
			this->labelHHB = (gcnew System::Windows::Forms::Label());
			this->numericLSB = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHSB = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLVB = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHVB = (gcnew System::Windows::Forms::NumericUpDown());
			this->labelLSB = (gcnew System::Windows::Forms::Label());
			this->labelHSB = (gcnew System::Windows::Forms::Label());
			this->labelLVB = (gcnew System::Windows::Forms::Label());
			this->labelHVB = (gcnew System::Windows::Forms::Label());
			this->numericLHU = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHHU = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLSU = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHSU = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLVU = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHVU = (gcnew System::Windows::Forms::NumericUpDown());
			this->labelLHU = (gcnew System::Windows::Forms::Label());
			this->labelHHU = (gcnew System::Windows::Forms::Label());
			this->labelLSU = (gcnew System::Windows::Forms::Label());
			this->labelHSU = (gcnew System::Windows::Forms::Label());
			this->labelLVU = (gcnew System::Windows::Forms::Label());
			this->labelHVU = (gcnew System::Windows::Forms::Label());
			this->numericLHT = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHHT = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLST = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHST = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLVT = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHVT = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLHS = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHHS = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLSS = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHSS = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericLVS = (gcnew System::Windows::Forms::NumericUpDown());
			this->numericHVS = (gcnew System::Windows::Forms::NumericUpDown());
			this->labelLHT = (gcnew System::Windows::Forms::Label());
			this->labelHHT = (gcnew System::Windows::Forms::Label());
			this->labelLST = (gcnew System::Windows::Forms::Label());
			this->labelHST = (gcnew System::Windows::Forms::Label());
			this->labelLVT = (gcnew System::Windows::Forms::Label());
			this->labelHVT = (gcnew System::Windows::Forms::Label());
			this->labelLHS = (gcnew System::Windows::Forms::Label());
			this->labelHHS = (gcnew System::Windows::Forms::Label());
			this->labelLSS = (gcnew System::Windows::Forms::Label());
			this->labelHSS = (gcnew System::Windows::Forms::Label());
			this->labelLVS = (gcnew System::Windows::Forms::Label());
			this->labelHVS = (gcnew System::Windows::Forms::Label());
			this->labelX = (gcnew System::Windows::Forms::Label());
			this->labelY = (gcnew System::Windows::Forms::Label());
			this->labelPosX = (gcnew System::Windows::Forms::Label());
			this->labelPosY = (gcnew System::Windows::Forms::Label());
			this->buttonPos = (gcnew System::Windows::Forms::Button());
			this->labelPosBaratY = (gcnew System::Windows::Forms::Label());
			this->labelPosUtaraX = (gcnew System::Windows::Forms::Label());
			this->labelPosSelatanY = (gcnew System::Windows::Forms::Label());
			this->labelPosTimurY = (gcnew System::Windows::Forms::Label());
			this->labelPosUtaraY = (gcnew System::Windows::Forms::Label());
			this->labelUY = (gcnew System::Windows::Forms::Label());
			this->labelUX = (gcnew System::Windows::Forms::Label());
			this->labelPosBaratX = (gcnew System::Windows::Forms::Label());
			this->labelBY = (gcnew System::Windows::Forms::Label());
			this->labelBX = (gcnew System::Windows::Forms::Label());
			this->labelPosTimurX = (gcnew System::Windows::Forms::Label());
			this->labelTY = (gcnew System::Windows::Forms::Label());
			this->labelTX = (gcnew System::Windows::Forms::Label());
			this->labelPosSelatanX = (gcnew System::Windows::Forms::Label());
			this->labelSY = (gcnew System::Windows::Forms::Label());
			this->labelSX = (gcnew System::Windows::Forms::Label());
			this->labelTengahX = (gcnew System::Windows::Forms::Label());
			this->labelTengahY = (gcnew System::Windows::Forms::Label());
			this->LTX = (gcnew System::Windows::Forms::Label());
			this->LTY = (gcnew System::Windows::Forms::Label());
			this->labelMarkX = (gcnew System::Windows::Forms::Label());
			this->labelMarkY = (gcnew System::Windows::Forms::Label());
			this->LMX = (gcnew System::Windows::Forms::Label());
			this->LMY = (gcnew System::Windows::Forms::Label());
			this->labelXcm = (gcnew System::Windows::Forms::Label());
			this->labelYcm = (gcnew System::Windows::Forms::Label());
			this->numericScale = (gcnew System::Windows::Forms::NumericUpDown());
			this->cm1 = (gcnew System::Windows::Forms::Label());
			this->cm2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxSrc))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxUtara))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxSelatan))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxTimur))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxBarat))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLSB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHSB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVB))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHU))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHU))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLSU))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHSU))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVU))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVU))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHT))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHT))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLST))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHST))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVT))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVT))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHS))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHS))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLSS))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHSS))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVS))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVS))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericScale))->BeginInit();
			this->SuspendLayout();
			// 
			// buttonOpenFile
			// 
			this->buttonOpenFile->Location = System::Drawing::Point(12, 12);
			this->buttonOpenFile->Name = L"buttonOpenFile";
			this->buttonOpenFile->Size = System::Drawing::Size(75, 23);
			this->buttonOpenFile->TabIndex = 0;
			this->buttonOpenFile->Text = L"Buka Citra";
			this->buttonOpenFile->UseVisualStyleBackColor = true;
			this->buttonOpenFile->Click += gcnew System::EventHandler(this, &MyForm::buttonOpenFile_Click);
			// 
			// pictureBoxSrc
			// 
			this->pictureBoxSrc->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->pictureBoxSrc->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBoxSrc->Location = System::Drawing::Point(12, 90);
			this->pictureBoxSrc->Name = L"pictureBoxSrc";
			this->pictureBoxSrc->Size = System::Drawing::Size(480, 570);
			this->pictureBoxSrc->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBoxSrc->TabIndex = 1;
			this->pictureBoxSrc->TabStop = false;
			// 
			// pictureBoxUtara
			// 
			this->pictureBoxUtara->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->pictureBoxUtara->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBoxUtara->Location = System::Drawing::Point(763, 40);
			this->pictureBoxUtara->Name = L"pictureBoxUtara";
			this->pictureBoxUtara->Size = System::Drawing::Size(240, 240);
			this->pictureBoxUtara->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBoxUtara->TabIndex = 2;
			this->pictureBoxUtara->TabStop = false;
			// 
			// pictureBoxSelatan
			// 
			this->pictureBoxSelatan->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->pictureBoxSelatan->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBoxSelatan->Location = System::Drawing::Point(763, 420);
			this->pictureBoxSelatan->Name = L"pictureBoxSelatan";
			this->pictureBoxSelatan->Size = System::Drawing::Size(240, 240);
			this->pictureBoxSelatan->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBoxSelatan->TabIndex = 3;
			this->pictureBoxSelatan->TabStop = false;
			// 
			// pictureBoxTimur
			// 
			this->pictureBoxTimur->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->pictureBoxTimur->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBoxTimur->Location = System::Drawing::Point(1020, 245);
			this->pictureBoxTimur->Name = L"pictureBoxTimur";
			this->pictureBoxTimur->Size = System::Drawing::Size(240, 240);
			this->pictureBoxTimur->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBoxTimur->TabIndex = 4;
			this->pictureBoxTimur->TabStop = false;
			// 
			// pictureBoxBarat
			// 
			this->pictureBoxBarat->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->pictureBoxBarat->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBoxBarat->Location = System::Drawing::Point(508, 245);
			this->pictureBoxBarat->Name = L"pictureBoxBarat";
			this->pictureBoxBarat->Size = System::Drawing::Size(240, 240);
			this->pictureBoxBarat->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBoxBarat->TabIndex = 5;
			this->pictureBoxBarat->TabStop = false;
			// 
			// labelUtara
			// 
			this->labelUtara->AutoSize = true;
			this->labelUtara->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelUtara->Location = System::Drawing::Point(1017, 40);
			this->labelUtara->Name = L"labelUtara";
			this->labelUtara->Size = System::Drawing::Size(38, 13);
			this->labelUtara->TabIndex = 7;
			this->labelUtara->Text = L"Utara";
			// 
			// labelTimur
			// 
			this->labelTimur->AutoSize = true;
			this->labelTimur->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelTimur->Location = System::Drawing::Point(1017, 488);
			this->labelTimur->Name = L"labelTimur";
			this->labelTimur->Size = System::Drawing::Size(38, 13);
			this->labelTimur->TabIndex = 8;
			this->labelTimur->Text = L"Timur";
			// 
			// labelBarat
			// 
			this->labelBarat->AutoSize = true;
			this->labelBarat->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelBarat->Location = System::Drawing::Point(505, 40);
			this->labelBarat->Name = L"labelBarat";
			this->labelBarat->Size = System::Drawing::Size(37, 13);
			this->labelBarat->TabIndex = 9;
			this->labelBarat->Text = L"Barat";
			// 
			// labelSelatan
			// 
			this->labelSelatan->AutoSize = true;
			this->labelSelatan->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->labelSelatan->Location = System::Drawing::Point(505, 488);
			this->labelSelatan->Name = L"labelSelatan";
			this->labelSelatan->Size = System::Drawing::Size(50, 13);
			this->labelSelatan->TabIndex = 10;
			this->labelSelatan->Text = L"Selatan";
			// 
			// openFileDialog
			// 
			this->openFileDialog->FileName = L"openFileDialog";
			// 
			// numericLHB
			// 
			this->numericLHB->Location = System::Drawing::Point(628, 83);
			this->numericLHB->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericLHB->Name = L"numericLHB";
			this->numericLHB->Size = System::Drawing::Size(120, 20);
			this->numericLHB->TabIndex = 11;
			this->numericLHB->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLHB_ValueChanged);
			// 
			// numericHHB
			// 
			this->numericHHB->Location = System::Drawing::Point(628, 109);
			this->numericHHB->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHB->Name = L"numericHHB";
			this->numericHHB->Size = System::Drawing::Size(120, 20);
			this->numericHHB->TabIndex = 12;
			this->numericHHB->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHB->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHHB_ValueChanged);
			// 
			// labelLHB
			// 
			this->labelLHB->AutoSize = true;
			this->labelLHB->Location = System::Drawing::Point(505, 85);
			this->labelLHB->Name = L"labelLHB";
			this->labelLHB->Size = System::Drawing::Size(35, 13);
			this->labelLHB->TabIndex = 13;
			this->labelLHB->Text = L"LowH";
			// 
			// labelHHB
			// 
			this->labelHHB->AutoSize = true;
			this->labelHHB->Location = System::Drawing::Point(505, 111);
			this->labelHHB->Name = L"labelHHB";
			this->labelHHB->Size = System::Drawing::Size(37, 13);
			this->labelHHB->TabIndex = 14;
			this->labelHHB->Text = L"HighH";
			// 
			// numericLSB
			// 
			this->numericLSB->Location = System::Drawing::Point(628, 136);
			this->numericLSB->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLSB->Name = L"numericLSB";
			this->numericLSB->Size = System::Drawing::Size(120, 20);
			this->numericLSB->TabIndex = 15;
			this->numericLSB->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLSB_ValueChanged);
			// 
			// numericHSB
			// 
			this->numericHSB->Location = System::Drawing::Point(628, 163);
			this->numericHSB->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHSB->Name = L"numericHSB";
			this->numericHSB->Size = System::Drawing::Size(120, 20);
			this->numericHSB->TabIndex = 16;
			this->numericHSB->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHSB->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHSB_ValueChanged);
			// 
			// numericLVB
			// 
			this->numericLVB->Location = System::Drawing::Point(628, 190);
			this->numericLVB->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLVB->Name = L"numericLVB";
			this->numericLVB->Size = System::Drawing::Size(120, 20);
			this->numericLVB->TabIndex = 17;
			this->numericLVB->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLVB_ValueChanged);
			// 
			// numericHVB
			// 
			this->numericHVB->Location = System::Drawing::Point(628, 217);
			this->numericHVB->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVB->Name = L"numericHVB";
			this->numericHVB->Size = System::Drawing::Size(120, 20);
			this->numericHVB->TabIndex = 18;
			this->numericHVB->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVB->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHVB_ValueChanged);
			// 
			// labelLSB
			// 
			this->labelLSB->AutoSize = true;
			this->labelLSB->Location = System::Drawing::Point(505, 138);
			this->labelLSB->Name = L"labelLSB";
			this->labelLSB->Size = System::Drawing::Size(34, 13);
			this->labelLSB->TabIndex = 19;
			this->labelLSB->Text = L"LowS";
			// 
			// labelHSB
			// 
			this->labelHSB->AutoSize = true;
			this->labelHSB->Location = System::Drawing::Point(505, 165);
			this->labelHSB->Name = L"labelHSB";
			this->labelHSB->Size = System::Drawing::Size(36, 13);
			this->labelHSB->TabIndex = 20;
			this->labelHSB->Text = L"HighS";
			// 
			// labelLVB
			// 
			this->labelLVB->AutoSize = true;
			this->labelLVB->Location = System::Drawing::Point(505, 190);
			this->labelLVB->Name = L"labelLVB";
			this->labelLVB->Size = System::Drawing::Size(34, 13);
			this->labelLVB->TabIndex = 21;
			this->labelLVB->Text = L"LowV";
			// 
			// labelHVB
			// 
			this->labelHVB->AutoSize = true;
			this->labelHVB->Location = System::Drawing::Point(505, 219);
			this->labelHVB->Name = L"labelHVB";
			this->labelHVB->Size = System::Drawing::Size(36, 13);
			this->labelHVB->TabIndex = 22;
			this->labelHVB->Text = L"HighV";
			// 
			// numericLHU
			// 
			this->numericLHU->Location = System::Drawing::Point(1140, 85);
			this->numericLHU->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericLHU->Name = L"numericLHU";
			this->numericLHU->Size = System::Drawing::Size(120, 20);
			this->numericLHU->TabIndex = 23;
			this->numericLHU->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLHU_ValueChanged);
			// 
			// numericHHU
			// 
			this->numericHHU->Location = System::Drawing::Point(1140, 111);
			this->numericHHU->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHU->Name = L"numericHHU";
			this->numericHHU->Size = System::Drawing::Size(120, 20);
			this->numericHHU->TabIndex = 24;
			this->numericHHU->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHU->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHHU_ValueChanged);
			// 
			// numericLSU
			// 
			this->numericLSU->Location = System::Drawing::Point(1140, 138);
			this->numericLSU->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLSU->Name = L"numericLSU";
			this->numericLSU->Size = System::Drawing::Size(120, 20);
			this->numericLSU->TabIndex = 25;
			this->numericLSU->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLSU_ValueChanged);
			// 
			// numericHSU
			// 
			this->numericHSU->Location = System::Drawing::Point(1140, 165);
			this->numericHSU->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHSU->Name = L"numericHSU";
			this->numericHSU->Size = System::Drawing::Size(120, 20);
			this->numericHSU->TabIndex = 26;
			this->numericHSU->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHSU->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHSU_ValueChanged);
			// 
			// numericLVU
			// 
			this->numericLVU->Location = System::Drawing::Point(1140, 193);
			this->numericLVU->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLVU->Name = L"numericLVU";
			this->numericLVU->Size = System::Drawing::Size(120, 20);
			this->numericLVU->TabIndex = 27;
			this->numericLVU->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLVU_ValueChanged);
			// 
			// numericHVU
			// 
			this->numericHVU->Location = System::Drawing::Point(1140, 219);
			this->numericHVU->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVU->Name = L"numericHVU";
			this->numericHVU->Size = System::Drawing::Size(120, 20);
			this->numericHVU->TabIndex = 28;
			this->numericHVU->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVU->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHVU_ValueChanged);
			// 
			// labelLHU
			// 
			this->labelLHU->AutoSize = true;
			this->labelLHU->Location = System::Drawing::Point(1017, 87);
			this->labelLHU->Name = L"labelLHU";
			this->labelLHU->Size = System::Drawing::Size(35, 13);
			this->labelLHU->TabIndex = 29;
			this->labelLHU->Text = L"LowH";
			// 
			// labelHHU
			// 
			this->labelHHU->AutoSize = true;
			this->labelHHU->Location = System::Drawing::Point(1017, 113);
			this->labelHHU->Name = L"labelHHU";
			this->labelHHU->Size = System::Drawing::Size(37, 13);
			this->labelHHU->TabIndex = 30;
			this->labelHHU->Text = L"HighH";
			// 
			// labelLSU
			// 
			this->labelLSU->AutoSize = true;
			this->labelLSU->Location = System::Drawing::Point(1017, 140);
			this->labelLSU->Name = L"labelLSU";
			this->labelLSU->Size = System::Drawing::Size(34, 13);
			this->labelLSU->TabIndex = 31;
			this->labelLSU->Text = L"LowS";
			// 
			// labelHSU
			// 
			this->labelHSU->AutoSize = true;
			this->labelHSU->Location = System::Drawing::Point(1017, 167);
			this->labelHSU->Name = L"labelHSU";
			this->labelHSU->Size = System::Drawing::Size(36, 13);
			this->labelHSU->TabIndex = 32;
			this->labelHSU->Text = L"HighS";
			// 
			// labelLVU
			// 
			this->labelLVU->AutoSize = true;
			this->labelLVU->Location = System::Drawing::Point(1017, 195);
			this->labelLVU->Name = L"labelLVU";
			this->labelLVU->Size = System::Drawing::Size(34, 13);
			this->labelLVU->TabIndex = 33;
			this->labelLVU->Text = L"LowV";
			// 
			// labelHVU
			// 
			this->labelHVU->AutoSize = true;
			this->labelHVU->Location = System::Drawing::Point(1017, 219);
			this->labelHVU->Name = L"labelHVU";
			this->labelHVU->Size = System::Drawing::Size(36, 13);
			this->labelHVU->TabIndex = 34;
			this->labelHVU->Text = L"HighV";
			// 
			// numericLHT
			// 
			this->numericLHT->Location = System::Drawing::Point(1140, 536);
			this->numericLHT->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericLHT->Name = L"numericLHT";
			this->numericLHT->Size = System::Drawing::Size(120, 20);
			this->numericLHT->TabIndex = 35;
			this->numericLHT->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLHT_ValueChanged);
			// 
			// numericHHT
			// 
			this->numericHHT->Location = System::Drawing::Point(1140, 562);
			this->numericHHT->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHT->Name = L"numericHHT";
			this->numericHHT->Size = System::Drawing::Size(120, 20);
			this->numericHHT->TabIndex = 36;
			this->numericHHT->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHT->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHHT_ValueChanged);
			// 
			// numericLST
			// 
			this->numericLST->Location = System::Drawing::Point(1140, 588);
			this->numericLST->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLST->Name = L"numericLST";
			this->numericLST->Size = System::Drawing::Size(120, 20);
			this->numericLST->TabIndex = 37;
			this->numericLST->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLST_ValueChanged);
			// 
			// numericHST
			// 
			this->numericHST->Location = System::Drawing::Point(1140, 614);
			this->numericHST->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHST->Name = L"numericHST";
			this->numericHST->Size = System::Drawing::Size(120, 20);
			this->numericHST->TabIndex = 38;
			this->numericHST->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHST->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHST_ValueChanged);
			// 
			// numericLVT
			// 
			this->numericLVT->Location = System::Drawing::Point(1140, 640);
			this->numericLVT->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLVT->Name = L"numericLVT";
			this->numericLVT->Size = System::Drawing::Size(120, 20);
			this->numericLVT->TabIndex = 39;
			this->numericLVT->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLVT_ValueChanged);
			// 
			// numericHVT
			// 
			this->numericHVT->Location = System::Drawing::Point(1140, 666);
			this->numericHVT->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVT->Name = L"numericHVT";
			this->numericHVT->Size = System::Drawing::Size(120, 20);
			this->numericHVT->TabIndex = 40;
			this->numericHVT->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVT->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHVT_ValueChanged);
			// 
			// numericLHS
			// 
			this->numericLHS->Location = System::Drawing::Point(628, 536);
			this->numericLHS->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericLHS->Name = L"numericLHS";
			this->numericLHS->Size = System::Drawing::Size(120, 20);
			this->numericLHS->TabIndex = 41;
			this->numericLHS->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLHS_ValueChanged);
			// 
			// numericHHS
			// 
			this->numericHHS->Location = System::Drawing::Point(628, 562);
			this->numericHHS->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHS->Name = L"numericHHS";
			this->numericHHS->Size = System::Drawing::Size(120, 20);
			this->numericHHS->TabIndex = 42;
			this->numericHHS->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {180, 0, 0, 0});
			this->numericHHS->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHHS_ValueChanged);
			// 
			// numericLSS
			// 
			this->numericLSS->Location = System::Drawing::Point(628, 588);
			this->numericLSS->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLSS->Name = L"numericLSS";
			this->numericLSS->Size = System::Drawing::Size(120, 20);
			this->numericLSS->TabIndex = 43;
			this->numericLSS->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLSS_ValueChanged);
			// 
			// numericHSS
			// 
			this->numericHSS->Location = System::Drawing::Point(628, 614);
			this->numericHSS->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHSS->Name = L"numericHSS";
			this->numericHSS->Size = System::Drawing::Size(120, 20);
			this->numericHSS->TabIndex = 44;
			this->numericHSS->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHSS->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHSS_ValueChanged);
			// 
			// numericLVS
			// 
			this->numericLVS->Location = System::Drawing::Point(628, 640);
			this->numericLVS->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericLVS->Name = L"numericLVS";
			this->numericLVS->Size = System::Drawing::Size(120, 20);
			this->numericLVS->TabIndex = 45;
			this->numericLVS->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericLVS_ValueChanged);
			// 
			// numericHVS
			// 
			this->numericHVS->Location = System::Drawing::Point(628, 666);
			this->numericHVS->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVS->Name = L"numericHVS";
			this->numericHVS->Size = System::Drawing::Size(120, 20);
			this->numericHVS->TabIndex = 46;
			this->numericHVS->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {255, 0, 0, 0});
			this->numericHVS->ValueChanged += gcnew System::EventHandler(this, &MyForm::numericHVS_ValueChanged);
			// 
			// labelLHT
			// 
			this->labelLHT->AutoSize = true;
			this->labelLHT->Location = System::Drawing::Point(1020, 538);
			this->labelLHT->Name = L"labelLHT";
			this->labelLHT->Size = System::Drawing::Size(35, 13);
			this->labelLHT->TabIndex = 47;
			this->labelLHT->Text = L"LowH";
			// 
			// labelHHT
			// 
			this->labelHHT->AutoSize = true;
			this->labelHHT->Location = System::Drawing::Point(1020, 564);
			this->labelHHT->Name = L"labelHHT";
			this->labelHHT->Size = System::Drawing::Size(37, 13);
			this->labelHHT->TabIndex = 48;
			this->labelHHT->Text = L"HighH";
			// 
			// labelLST
			// 
			this->labelLST->AutoSize = true;
			this->labelLST->Location = System::Drawing::Point(1020, 590);
			this->labelLST->Name = L"labelLST";
			this->labelLST->Size = System::Drawing::Size(34, 13);
			this->labelLST->TabIndex = 49;
			this->labelLST->Text = L"LowS";
			// 
			// labelHST
			// 
			this->labelHST->AutoSize = true;
			this->labelHST->Location = System::Drawing::Point(1020, 616);
			this->labelHST->Name = L"labelHST";
			this->labelHST->Size = System::Drawing::Size(36, 13);
			this->labelHST->TabIndex = 50;
			this->labelHST->Text = L"HighS";
			// 
			// labelLVT
			// 
			this->labelLVT->AutoSize = true;
			this->labelLVT->Location = System::Drawing::Point(1020, 642);
			this->labelLVT->Name = L"labelLVT";
			this->labelLVT->Size = System::Drawing::Size(34, 13);
			this->labelLVT->TabIndex = 51;
			this->labelLVT->Text = L"LowV";
			// 
			// labelHVT
			// 
			this->labelHVT->AutoSize = true;
			this->labelHVT->Location = System::Drawing::Point(1020, 668);
			this->labelHVT->Name = L"labelHVT";
			this->labelHVT->Size = System::Drawing::Size(36, 13);
			this->labelHVT->TabIndex = 52;
			this->labelHVT->Text = L"HighV";
			// 
			// labelLHS
			// 
			this->labelLHS->AutoSize = true;
			this->labelLHS->Location = System::Drawing::Point(505, 538);
			this->labelLHS->Name = L"labelLHS";
			this->labelLHS->Size = System::Drawing::Size(35, 13);
			this->labelLHS->TabIndex = 53;
			this->labelLHS->Text = L"LowH";
			// 
			// labelHHS
			// 
			this->labelHHS->AutoSize = true;
			this->labelHHS->Location = System::Drawing::Point(505, 564);
			this->labelHHS->Name = L"labelHHS";
			this->labelHHS->Size = System::Drawing::Size(37, 13);
			this->labelHHS->TabIndex = 54;
			this->labelHHS->Text = L"HighH";
			// 
			// labelLSS
			// 
			this->labelLSS->AutoSize = true;
			this->labelLSS->Location = System::Drawing::Point(505, 590);
			this->labelLSS->Name = L"labelLSS";
			this->labelLSS->Size = System::Drawing::Size(34, 13);
			this->labelLSS->TabIndex = 55;
			this->labelLSS->Text = L"LowS";
			// 
			// labelHSS
			// 
			this->labelHSS->AutoSize = true;
			this->labelHSS->Location = System::Drawing::Point(505, 616);
			this->labelHSS->Name = L"labelHSS";
			this->labelHSS->Size = System::Drawing::Size(36, 13);
			this->labelHSS->TabIndex = 56;
			this->labelHSS->Text = L"HighS";
			// 
			// labelLVS
			// 
			this->labelLVS->AutoSize = true;
			this->labelLVS->Location = System::Drawing::Point(505, 642);
			this->labelLVS->Name = L"labelLVS";
			this->labelLVS->Size = System::Drawing::Size(34, 13);
			this->labelLVS->TabIndex = 57;
			this->labelLVS->Text = L"LowV";
			// 
			// labelHVS
			// 
			this->labelHVS->AutoSize = true;
			this->labelHVS->Location = System::Drawing::Point(505, 668);
			this->labelHVS->Name = L"labelHVS";
			this->labelHVS->Size = System::Drawing::Size(36, 13);
			this->labelHVS->TabIndex = 58;
			this->labelHVS->Text = L"HighV";
			// 
			// labelX
			// 
			this->labelX->AutoSize = true;
			this->labelX->Location = System::Drawing::Point(12, 40);
			this->labelX->Name = L"labelX";
			this->labelX->Size = System::Drawing::Size(50, 13);
			this->labelX->TabIndex = 59;
			this->labelX->Text = L"Posisi X :";
			// 
			// labelY
			// 
			this->labelY->AutoSize = true;
			this->labelY->Location = System::Drawing::Point(12, 56);
			this->labelY->Name = L"labelY";
			this->labelY->Size = System::Drawing::Size(50, 13);
			this->labelY->TabIndex = 60;
			this->labelY->Text = L"Posisi Y :";
			// 
			// labelPosX
			// 
			this->labelPosX->AutoSize = true;
			this->labelPosX->Location = System::Drawing::Point(77, 40);
			this->labelPosX->Name = L"labelPosX";
			this->labelPosX->Size = System::Drawing::Size(13, 13);
			this->labelPosX->TabIndex = 61;
			this->labelPosX->Text = L"0";
			// 
			// labelPosY
			// 
			this->labelPosY->AutoSize = true;
			this->labelPosY->Location = System::Drawing::Point(77, 56);
			this->labelPosY->Name = L"labelPosY";
			this->labelPosY->Size = System::Drawing::Size(13, 13);
			this->labelPosY->TabIndex = 62;
			this->labelPosY->Text = L"0";
			// 
			// buttonPos
			// 
			this->buttonPos->Location = System::Drawing::Point(117, 12);
			this->buttonPos->Name = L"buttonPos";
			this->buttonPos->Size = System::Drawing::Size(75, 23);
			this->buttonPos->TabIndex = 63;
			this->buttonPos->Text = L"Cek Posisi";
			this->buttonPos->UseVisualStyleBackColor = true;
			this->buttonPos->Click += gcnew System::EventHandler(this, &MyForm::buttonPos_Click);
			// 
			// labelPosBaratY
			// 
			this->labelPosBaratY->AutoSize = true;
			this->labelPosBaratY->Location = System::Drawing::Point(669, 40);
			this->labelPosBaratY->Name = L"labelPosBaratY";
			this->labelPosBaratY->Size = System::Drawing::Size(79, 13);
			this->labelPosBaratY->TabIndex = 64;
			this->labelPosBaratY->Text = L"labelPosBaratY";
			// 
			// labelPosUtaraX
			// 
			this->labelPosUtaraX->AutoSize = true;
			this->labelPosUtaraX->Location = System::Drawing::Point(1180, 53);
			this->labelPosUtaraX->Name = L"labelPosUtaraX";
			this->labelPosUtaraX->Size = System::Drawing::Size(80, 13);
			this->labelPosUtaraX->TabIndex = 65;
			this->labelPosUtaraX->Text = L"labelPosUtaraX";
			// 
			// labelPosSelatanY
			// 
			this->labelPosSelatanY->AutoSize = true;
			this->labelPosSelatanY->Location = System::Drawing::Point(658, 488);
			this->labelPosSelatanY->Name = L"labelPosSelatanY";
			this->labelPosSelatanY->Size = System::Drawing::Size(90, 13);
			this->labelPosSelatanY->TabIndex = 66;
			this->labelPosSelatanY->Text = L"labelPosSelatanY";
			// 
			// labelPosTimurY
			// 
			this->labelPosTimurY->AutoSize = true;
			this->labelPosTimurY->Location = System::Drawing::Point(1180, 488);
			this->labelPosTimurY->Name = L"labelPosTimurY";
			this->labelPosTimurY->Size = System::Drawing::Size(80, 13);
			this->labelPosTimurY->TabIndex = 67;
			this->labelPosTimurY->Text = L"labelPosTimurY";
			// 
			// labelPosUtaraY
			// 
			this->labelPosUtaraY->AutoSize = true;
			this->labelPosUtaraY->Location = System::Drawing::Point(1180, 40);
			this->labelPosUtaraY->Name = L"labelPosUtaraY";
			this->labelPosUtaraY->Size = System::Drawing::Size(80, 13);
			this->labelPosUtaraY->TabIndex = 68;
			this->labelPosUtaraY->Text = L"labelPosUtaraY";
			// 
			// labelUY
			// 
			this->labelUY->AutoSize = true;
			this->labelUY->Location = System::Drawing::Point(1103, 40);
			this->labelUY->Name = L"labelUY";
			this->labelUY->Size = System::Drawing::Size(14, 13);
			this->labelUY->TabIndex = 69;
			this->labelUY->Text = L"Y";
			// 
			// labelUX
			// 
			this->labelUX->AutoSize = true;
			this->labelUX->Location = System::Drawing::Point(1103, 56);
			this->labelUX->Name = L"labelUX";
			this->labelUX->Size = System::Drawing::Size(14, 13);
			this->labelUX->TabIndex = 70;
			this->labelUX->Text = L"X";
			// 
			// labelPosBaratX
			// 
			this->labelPosBaratX->AutoSize = true;
			this->labelPosBaratX->Location = System::Drawing::Point(669, 56);
			this->labelPosBaratX->Name = L"labelPosBaratX";
			this->labelPosBaratX->Size = System::Drawing::Size(79, 13);
			this->labelPosBaratX->TabIndex = 71;
			this->labelPosBaratX->Text = L"labelPosBaratX";
			// 
			// labelBY
			// 
			this->labelBY->AutoSize = true;
			this->labelBY->Location = System::Drawing::Point(590, 40);
			this->labelBY->Name = L"labelBY";
			this->labelBY->Size = System::Drawing::Size(14, 13);
			this->labelBY->TabIndex = 72;
			this->labelBY->Text = L"Y";
			// 
			// labelBX
			// 
			this->labelBX->AutoSize = true;
			this->labelBX->Location = System::Drawing::Point(590, 56);
			this->labelBX->Name = L"labelBX";
			this->labelBX->Size = System::Drawing::Size(14, 13);
			this->labelBX->TabIndex = 73;
			this->labelBX->Text = L"X";
			// 
			// labelPosTimurX
			// 
			this->labelPosTimurX->AutoSize = true;
			this->labelPosTimurX->Location = System::Drawing::Point(1180, 504);
			this->labelPosTimurX->Name = L"labelPosTimurX";
			this->labelPosTimurX->Size = System::Drawing::Size(80, 13);
			this->labelPosTimurX->TabIndex = 74;
			this->labelPosTimurX->Text = L"labelPosTimurX";
			// 
			// labelTY
			// 
			this->labelTY->AutoSize = true;
			this->labelTY->Location = System::Drawing::Point(1094, 488);
			this->labelTY->Name = L"labelTY";
			this->labelTY->Size = System::Drawing::Size(14, 13);
			this->labelTY->TabIndex = 75;
			this->labelTY->Text = L"Y";
			// 
			// labelTX
			// 
			this->labelTX->AutoSize = true;
			this->labelTX->Location = System::Drawing::Point(1094, 504);
			this->labelTX->Name = L"labelTX";
			this->labelTX->Size = System::Drawing::Size(14, 13);
			this->labelTX->TabIndex = 76;
			this->labelTX->Text = L"X";
			// 
			// labelPosSelatanX
			// 
			this->labelPosSelatanX->AutoSize = true;
			this->labelPosSelatanX->Location = System::Drawing::Point(658, 501);
			this->labelPosSelatanX->Name = L"labelPosSelatanX";
			this->labelPosSelatanX->Size = System::Drawing::Size(90, 13);
			this->labelPosSelatanX->TabIndex = 77;
			this->labelPosSelatanX->Text = L"labelPosSelatanX";
			// 
			// labelSY
			// 
			this->labelSY->AutoSize = true;
			this->labelSY->Location = System::Drawing::Point(580, 488);
			this->labelSY->Name = L"labelSY";
			this->labelSY->Size = System::Drawing::Size(14, 13);
			this->labelSY->TabIndex = 78;
			this->labelSY->Text = L"Y";
			// 
			// labelSX
			// 
			this->labelSX->AutoSize = true;
			this->labelSX->Location = System::Drawing::Point(580, 504);
			this->labelSX->Name = L"labelSX";
			this->labelSX->Size = System::Drawing::Size(14, 13);
			this->labelSX->TabIndex = 79;
			this->labelSX->Text = L"X";
			// 
			// labelTengahX
			// 
			this->labelTengahX->AutoSize = true;
			this->labelTengahX->Location = System::Drawing::Point(339, 53);
			this->labelTengahX->Name = L"labelTengahX";
			this->labelTengahX->Size = System::Drawing::Size(60, 13);
			this->labelTengahX->TabIndex = 80;
			this->labelTengahX->Text = L"Tengah X :";
			// 
			// labelTengahY
			// 
			this->labelTengahY->AutoSize = true;
			this->labelTengahY->Location = System::Drawing::Point(339, 69);
			this->labelTengahY->Name = L"labelTengahY";
			this->labelTengahY->Size = System::Drawing::Size(60, 13);
			this->labelTengahY->TabIndex = 81;
			this->labelTengahY->Text = L"Tengah Y :";
			// 
			// LTX
			// 
			this->LTX->AutoSize = true;
			this->LTX->Location = System::Drawing::Point(417, 53);
			this->LTX->Name = L"LTX";
			this->LTX->Size = System::Drawing::Size(14, 13);
			this->LTX->TabIndex = 82;
			this->LTX->Text = L"X";
			// 
			// LTY
			// 
			this->LTY->AutoSize = true;
			this->LTY->Location = System::Drawing::Point(417, 69);
			this->LTY->Name = L"LTY";
			this->LTY->Size = System::Drawing::Size(14, 13);
			this->LTY->TabIndex = 83;
			this->LTY->Text = L"Y";
			// 
			// labelMarkX
			// 
			this->labelMarkX->AutoSize = true;
			this->labelMarkX->Location = System::Drawing::Point(342, 12);
			this->labelMarkX->Name = L"labelMarkX";
			this->labelMarkX->Size = System::Drawing::Size(44, 13);
			this->labelMarkX->TabIndex = 84;
			this->labelMarkX->Text = L"MarkX :";
			// 
			// labelMarkY
			// 
			this->labelMarkY->AutoSize = true;
			this->labelMarkY->Location = System::Drawing::Point(342, 25);
			this->labelMarkY->Name = L"labelMarkY";
			this->labelMarkY->Size = System::Drawing::Size(44, 13);
			this->labelMarkY->TabIndex = 85;
			this->labelMarkY->Text = L"MarkY :";
			// 
			// LMX
			// 
			this->LMX->AutoSize = true;
			this->LMX->Location = System::Drawing::Point(396, 12);
			this->LMX->Name = L"LMX";
			this->LMX->Size = System::Drawing::Size(14, 13);
			this->LMX->TabIndex = 86;
			this->LMX->Text = L"X";
			// 
			// LMY
			// 
			this->LMY->AutoSize = true;
			this->LMY->Location = System::Drawing::Point(396, 25);
			this->LMY->Name = L"LMY";
			this->LMY->Size = System::Drawing::Size(14, 13);
			this->LMY->TabIndex = 87;
			this->LMY->Text = L"Y";
			// 
			// labelXcm
			// 
			this->labelXcm->AutoSize = true;
			this->labelXcm->Location = System::Drawing::Point(146, 40);
			this->labelXcm->Name = L"labelXcm";
			this->labelXcm->Size = System::Drawing::Size(31, 13);
			this->labelXcm->TabIndex = 88;
			this->labelXcm->Text = L"X cm";
			// 
			// labelYcm
			// 
			this->labelYcm->AutoSize = true;
			this->labelYcm->Location = System::Drawing::Point(146, 56);
			this->labelYcm->Name = L"labelYcm";
			this->labelYcm->Size = System::Drawing::Size(31, 13);
			this->labelYcm->TabIndex = 89;
			this->labelYcm->Text = L"Y cm";
			// 
			// numericScale
			// 
			this->numericScale->DecimalPlaces = 2;
			this->numericScale->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 65536});
			this->numericScale->Location = System::Drawing::Point(216, 15);
			this->numericScale->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {10000, 0, 0, 0});
			this->numericScale->Name = L"numericScale";
			this->numericScale->Size = System::Drawing::Size(76, 20);
			this->numericScale->TabIndex = 90;
			this->numericScale->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			// 
			// cm1
			// 
			this->cm1->AutoSize = true;
			this->cm1->Location = System::Drawing::Point(243, 43);
			this->cm1->Name = L"cm1";
			this->cm1->Size = System::Drawing::Size(21, 13);
			this->cm1->TabIndex = 91;
			this->cm1->Text = L"cm";
			// 
			// cm2
			// 
			this->cm2->AutoSize = true;
			this->cm2->Location = System::Drawing::Point(243, 56);
			this->cm2->Name = L"cm2";
			this->cm2->Size = System::Drawing::Size(21, 13);
			this->cm2->TabIndex = 92;
			this->cm2->Text = L"cm";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1272, 693);
			this->Controls->Add(this->cm2);
			this->Controls->Add(this->cm1);
			this->Controls->Add(this->numericScale);
			this->Controls->Add(this->labelYcm);
			this->Controls->Add(this->labelXcm);
			this->Controls->Add(this->LMY);
			this->Controls->Add(this->LMX);
			this->Controls->Add(this->labelMarkY);
			this->Controls->Add(this->labelMarkX);
			this->Controls->Add(this->LTY);
			this->Controls->Add(this->LTX);
			this->Controls->Add(this->labelTengahY);
			this->Controls->Add(this->labelTengahX);
			this->Controls->Add(this->labelSX);
			this->Controls->Add(this->labelSY);
			this->Controls->Add(this->labelPosSelatanX);
			this->Controls->Add(this->labelTX);
			this->Controls->Add(this->labelTY);
			this->Controls->Add(this->labelPosTimurX);
			this->Controls->Add(this->labelBX);
			this->Controls->Add(this->labelBY);
			this->Controls->Add(this->labelPosBaratX);
			this->Controls->Add(this->labelUX);
			this->Controls->Add(this->labelUY);
			this->Controls->Add(this->labelPosUtaraY);
			this->Controls->Add(this->labelPosTimurY);
			this->Controls->Add(this->labelPosSelatanY);
			this->Controls->Add(this->labelPosUtaraX);
			this->Controls->Add(this->labelPosBaratY);
			this->Controls->Add(this->buttonPos);
			this->Controls->Add(this->labelPosY);
			this->Controls->Add(this->labelPosX);
			this->Controls->Add(this->labelY);
			this->Controls->Add(this->labelX);
			this->Controls->Add(this->labelHVS);
			this->Controls->Add(this->labelLVS);
			this->Controls->Add(this->labelHSS);
			this->Controls->Add(this->labelLSS);
			this->Controls->Add(this->labelHHS);
			this->Controls->Add(this->labelLHS);
			this->Controls->Add(this->labelHVT);
			this->Controls->Add(this->labelLVT);
			this->Controls->Add(this->labelHST);
			this->Controls->Add(this->labelLST);
			this->Controls->Add(this->labelHHT);
			this->Controls->Add(this->labelLHT);
			this->Controls->Add(this->numericHVS);
			this->Controls->Add(this->numericLVS);
			this->Controls->Add(this->numericHSS);
			this->Controls->Add(this->numericLSS);
			this->Controls->Add(this->numericHHS);
			this->Controls->Add(this->numericLHS);
			this->Controls->Add(this->numericHVT);
			this->Controls->Add(this->numericLVT);
			this->Controls->Add(this->numericHST);
			this->Controls->Add(this->numericLST);
			this->Controls->Add(this->numericHHT);
			this->Controls->Add(this->numericLHT);
			this->Controls->Add(this->labelHVU);
			this->Controls->Add(this->labelLVU);
			this->Controls->Add(this->labelHSU);
			this->Controls->Add(this->labelLSU);
			this->Controls->Add(this->labelHHU);
			this->Controls->Add(this->labelLHU);
			this->Controls->Add(this->numericHVU);
			this->Controls->Add(this->numericLVU);
			this->Controls->Add(this->numericHSU);
			this->Controls->Add(this->numericLSU);
			this->Controls->Add(this->numericHHU);
			this->Controls->Add(this->numericLHU);
			this->Controls->Add(this->labelHVB);
			this->Controls->Add(this->labelLVB);
			this->Controls->Add(this->labelHSB);
			this->Controls->Add(this->labelLSB);
			this->Controls->Add(this->numericHVB);
			this->Controls->Add(this->numericLVB);
			this->Controls->Add(this->numericHSB);
			this->Controls->Add(this->numericLSB);
			this->Controls->Add(this->labelHHB);
			this->Controls->Add(this->labelLHB);
			this->Controls->Add(this->numericHHB);
			this->Controls->Add(this->numericLHB);
			this->Controls->Add(this->labelSelatan);
			this->Controls->Add(this->labelBarat);
			this->Controls->Add(this->labelTimur);
			this->Controls->Add(this->labelUtara);
			this->Controls->Add(this->pictureBoxBarat);
			this->Controls->Add(this->pictureBoxTimur);
			this->Controls->Add(this->pictureBoxSelatan);
			this->Controls->Add(this->pictureBoxUtara);
			this->Controls->Add(this->pictureBoxSrc);
			this->Controls->Add(this->buttonOpenFile);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Tugas UAS - Lokalisasi Mobot";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxSrc))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxUtara))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxSelatan))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxTimur))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBoxBarat))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLSB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHSB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVB))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHU))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHU))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLSU))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHSU))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVU))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVU))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHT))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHT))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLST))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHST))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVT))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVT))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLHS))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHHS))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLSS))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHSS))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericLVS))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericHVS))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericScale))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void buttonOpenFile_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 //membuka citra
			 if (openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK)
			 {
				 System::IO::StreamReader ^ sr = gcnew
					 System::IO::StreamReader(openFileDialog->FileName);
				 sr->Close();
				 dialogStatus = 1;
			 }
			 
			 if (dialogStatus == 1)
			 {
				 System::String^ dialogPath;
				 std::string dialogDir;
				 
				 //konversi tipe data string untuk file name
				 dialogPath = openFileDialog->FileName;
				 using namespace Runtime::InteropServices;
				 const char* chars =
					 (const char*)(Marshal::StringToHGlobalAnsi(dialogPath)).ToPointer();
				 dialogDir = chars;
				 Marshal::FreeHGlobal(IntPtr((void*)chars));
				 
				 //membuka gambar sumber
				 src = cv::imread(dialogDir);
				 //imwrite("./input.bmp", src);
				 //this->pictureBoxSrc->ImageLocation = "./input.bmp";
				 this->pictureBoxSrc->Image = MatToBitmap(src);
				 
				 //menampilkan citra barat
				 cvtColor(src, barat_, cv::COLOR_BGR2HSV);
				 iLowH[barat] = Convert::ToInt16(numericLHB->Value);
				 iHighH[barat] = Convert::ToInt16(numericHHB->Value);
				 iLowS[barat] = Convert::ToInt16(numericLSB->Value);
				 iHighS[barat] = Convert::ToInt16(numericHSB->Value);
				 iLowV[barat] = Convert::ToInt16(numericLVB->Value);
				 iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
				 inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
				 //morphological opening (remove small objects from the foreground)
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./barat.bmp", barat_);
				 //this->pictureBoxBarat->ImageLocation = "./barat.bmp";
				 this->pictureBoxBarat->Image = MatToBitmap(barat_);
				 
				 //menampilkan citra timur
				 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
				 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
				 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
				 iLowS[timur] = Convert::ToInt16(numericLST->Value);
				 iHighS[timur] = Convert::ToInt16(numericHST->Value);
				 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
				 iHighV[timur] = Convert::ToInt16(numericHVT->Value);
				 
				 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
				 //morphological opening (remove small objects from the foreground)
				 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./timur.bmp", timur_);
				 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
				 this->pictureBoxTimur->Image = MatToBitmap(timur_);
				 
				 //menampilkan citra utara
				 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
				 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
				 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
				 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
				 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
				 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
				 iHighV[utara] = Convert::ToInt16(numericHVU->Value);
				 
				 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
				 //morphological opening (remove small objects from the foreground)
				 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./utara.bmp", utara_);
				 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
				 this->pictureBoxUtara->Image = MatToBitmap(utara_);
				 
				 //menampilkan citra selatan
				 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
				 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
				 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
				 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
				 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
				 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
				 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);
				 
				 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
				 //morphological opening (remove small objects from the foreground)
				 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./selatan.bmp", selatan_);
				 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
				 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
					
				 /*coba-coba 15 Juni 2015*/
				 //750,60
				 //this->labelPosX->Text = Convert::ToString(barat_.at<uchar>(750, 60));
				 //this->labelPosY->Text = Convert::ToString(barat_.channels());

				 this->LTX->Text = Convert::ToString(src.cols/2);
				 this->LTY->Text = Convert::ToString(src.rows/2);
				 centerImX = src.cols/2;
				 centerImY = src.rows/2;
				}
		 }
private: System::Void numericLHB_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra barat
			cvtColor(src, barat_, cv::COLOR_BGR2HSV);
			iLowH[barat] = Convert::ToInt16(numericLHB->Value);
			iHighH[barat] = Convert::ToInt16(numericHHB->Value);
			iLowS[barat] = Convert::ToInt16(numericLSB->Value);
			iHighS[barat] = Convert::ToInt16(numericHSB->Value);
			iLowV[barat] = Convert::ToInt16(numericLVB->Value);
			iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
			inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
			//morphological opening (remove small objects from the foreground)
			erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
			dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
			//morphological closing (fill small holes in the foreground)
			dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
			erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
			//imwrite("./barat.bmp", barat_);
			//this->pictureBoxBarat->ImageLocation = "./barat.bmp";
			this->pictureBoxBarat->Image = MatToBitmap(barat_);
		 }
private: System::Void numericHHB_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra barat
				 cvtColor(src, barat_, cv::COLOR_BGR2HSV);
				 iLowH[barat] = Convert::ToInt16(numericLHB->Value);
				 iHighH[barat] = Convert::ToInt16(numericHHB->Value);
				 iLowS[barat] = Convert::ToInt16(numericLSB->Value);
				 iHighS[barat] = Convert::ToInt16(numericHSB->Value);
				 iLowV[barat] = Convert::ToInt16(numericLVB->Value);
				 iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
				 inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
				 //morphological opening (remove small objects from the foreground)
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./barat.bmp", barat_);
				 //this->pictureBoxBarat->ImageLocation = "./barat.bmp";
				 this->pictureBoxBarat->Image = MatToBitmap(barat_);
		 }
private: System::Void numericLSB_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra barat
				 cvtColor(src, barat_, cv::COLOR_BGR2HSV);
				 iLowH[barat] = Convert::ToInt16(numericLHB->Value);
				 iHighH[barat] = Convert::ToInt16(numericHHB->Value);
				 iLowS[barat] = Convert::ToInt16(numericLSB->Value);
				 iHighS[barat] = Convert::ToInt16(numericHSB->Value);
				 iLowV[barat] = Convert::ToInt16(numericLVB->Value);
				 iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
				 inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
				 //morphological opening (remove small objects from the foreground)
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./barat.bmp", barat_);
				 //this->pictureBoxBarat->ImageLocation = "./barat.bmp";
				 this->pictureBoxBarat->Image = MatToBitmap(barat_);
		 }
private: System::Void numericHSB_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra barat
				 cvtColor(src, barat_, cv::COLOR_BGR2HSV);
				 iLowH[barat] = Convert::ToInt16(numericLHB->Value);
				 iHighH[barat] = Convert::ToInt16(numericHHB->Value);
				 iLowS[barat] = Convert::ToInt16(numericLSB->Value);
				 iHighS[barat] = Convert::ToInt16(numericHSB->Value);
				 iLowV[barat] = Convert::ToInt16(numericLVB->Value);
				 iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
				 inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
				 //morphological opening (remove small objects from the foreground)
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./barat.bmp", barat_);
				 //this->pictureBoxBarat->ImageLocation = "./barat.bmp";
				 this->pictureBoxBarat->Image = MatToBitmap(barat_);
		 }
private: System::Void numericLVB_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra barat
				 cvtColor(src, barat_, cv::COLOR_BGR2HSV);
				 iLowH[barat] = Convert::ToInt16(numericLHB->Value);
				 iHighH[barat] = Convert::ToInt16(numericHHB->Value);
				 iLowS[barat] = Convert::ToInt16(numericLSB->Value);
				 iHighS[barat] = Convert::ToInt16(numericHSB->Value);
				 iLowV[barat] = Convert::ToInt16(numericLVB->Value);
				 iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
				 inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
				 //morphological opening (remove small objects from the foreground)
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./barat.bmp", barat_);
				 //this->pictureBoxBarat->ImageLocation = "./barat.bmp";
				 this->pictureBoxBarat->Image = MatToBitmap(barat_);
		 }
private: System::Void numericHVB_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra barat
				 cvtColor(src, barat_, cv::COLOR_BGR2HSV);
				 iLowH[barat] = Convert::ToInt16(numericLHB->Value);
				 iHighH[barat] = Convert::ToInt16(numericHHB->Value);
				 iLowS[barat] = Convert::ToInt16(numericLSB->Value);
				 iHighS[barat] = Convert::ToInt16(numericHSB->Value);
				 iLowV[barat] = Convert::ToInt16(numericLVB->Value);
				 iHighV[barat] = Convert::ToInt16(numericHVB->Value);
				 
				 inRange(barat_, Scalar(iLowH[barat], iLowS[barat], iLowV[barat]), Scalar(iHighH[barat], iHighS[barat], iHighV[barat]), barat_);
				 //morphological opening (remove small objects from the foreground)
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //morphological closing (fill small holes in the foreground)
				 dilate(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 erode(barat_, barat_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
				 
				 //imwrite("./barat.bmp", barat_);
				 //this->pictureBoxBarat->ImageLocation = "./barat.bmp";
				 this->pictureBoxBarat->Image = MatToBitmap(barat_);
		 }
private: System::Void numericLHU_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra utara
					 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
					 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
					 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
 					 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
					 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
					 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
					 iHighV[utara] = Convert::ToInt16(numericHVU->Value);


					 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
					 //morphological opening (remove small objects from the foreground)
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./utara.bmp", utara_);
					 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
					 this->pictureBoxUtara->Image = MatToBitmap(utara_);
		 }
private: System::Void numericHHU_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra utara
					 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
					 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
					 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
 					 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
					 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
					 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
					 iHighV[utara] = Convert::ToInt16(numericHVU->Value);


					 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
					 //morphological opening (remove small objects from the foreground)
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./utara.bmp", utara_);
					 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
					 this->pictureBoxUtara->Image = MatToBitmap(utara_);
		 }
private: System::Void numericLSU_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra utara
					 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
					 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
					 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
 					 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
					 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
					 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
					 iHighV[utara] = Convert::ToInt16(numericHVU->Value);


					 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
					 //morphological opening (remove small objects from the foreground)
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./utara.bmp", utara_);
					 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
					 this->pictureBoxUtara->Image = MatToBitmap(utara_);
		 }
private: System::Void numericHSU_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra utara
					 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
					 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
					 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
 					 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
					 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
					 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
					 iHighV[utara] = Convert::ToInt16(numericHVU->Value);


					 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
					 //morphological opening (remove small objects from the foreground)
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./utara.bmp", utara_);
					 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
					 this->pictureBoxUtara->Image = MatToBitmap(utara_);
		 }
private: System::Void numericLVU_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra utara
					 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
					 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
					 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
 					 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
					 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
					 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
					 iHighV[utara] = Convert::ToInt16(numericHVU->Value);


					 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
					 //morphological opening (remove small objects from the foreground)
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./utara.bmp", utara_);
					 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
					 this->pictureBoxUtara->Image = MatToBitmap(utara_);
		 }
private: System::Void numericHVU_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra utara
					 cvtColor(src, utara_, cv::COLOR_BGR2HSV);
					 iLowH[utara] = Convert::ToInt16(numericLHU->Value);
					 iHighH[utara] = Convert::ToInt16(numericHHU->Value);
 					 iLowS[utara] = Convert::ToInt16(numericLSU->Value);
					 iHighS[utara] = Convert::ToInt16(numericHSU->Value);
					 iLowV[utara] = Convert::ToInt16(numericLVU->Value);
					 iHighV[utara] = Convert::ToInt16(numericHVU->Value);


					 inRange(utara_, Scalar(iLowH[utara], iLowS[utara], iLowV[utara]), Scalar(iHighH[utara], iHighS[utara], iHighV[utara]), utara_);
					 //morphological opening (remove small objects from the foreground)
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(utara_, utara_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./utara.bmp", utara_);
					 //this->pictureBoxUtara->ImageLocation = "./utara.bmp";
					 this->pictureBoxUtara->Image = MatToBitmap(utara_);
		 }
private: System::Void numericLHT_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra timur
					 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
					 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
					 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
 					 iLowS[timur] = Convert::ToInt16(numericLST->Value);
					 iHighS[timur] = Convert::ToInt16(numericHST->Value);
					 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
					 iHighV[timur] = Convert::ToInt16(numericHVT->Value);


					 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
					 //morphological opening (remove small objects from the foreground)
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./timur.bmp", timur_);
					 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
					 this->pictureBoxTimur->Image = MatToBitmap(timur_);
		 }
private: System::Void numericHHT_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra timur
					 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
					 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
					 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
 					 iLowS[timur] = Convert::ToInt16(numericLST->Value);
					 iHighS[timur] = Convert::ToInt16(numericHST->Value);
					 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
					 iHighV[timur] = Convert::ToInt16(numericHVT->Value);


					 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
					 //morphological opening (remove small objects from the foreground)
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./timur.bmp", timur_);
					 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
					 this->pictureBoxTimur->Image = MatToBitmap(timur_);
		 }
private: System::Void numericLST_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra timur
					 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
					 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
					 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
 					 iLowS[timur] = Convert::ToInt16(numericLST->Value);
					 iHighS[timur] = Convert::ToInt16(numericHST->Value);
					 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
					 iHighV[timur] = Convert::ToInt16(numericHVT->Value);


					 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
					 //morphological opening (remove small objects from the foreground)
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./timur.bmp", timur_);
					 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
					 this->pictureBoxTimur->Image = MatToBitmap(timur_);
		 }
private: System::Void numericHST_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra timur
					 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
					 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
					 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
 					 iLowS[timur] = Convert::ToInt16(numericLST->Value);
					 iHighS[timur] = Convert::ToInt16(numericHST->Value);
					 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
					 iHighV[timur] = Convert::ToInt16(numericHVT->Value);


					 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
					 //morphological opening (remove small objects from the foreground)
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./timur.bmp", timur_);
					 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
					 this->pictureBoxTimur->Image = MatToBitmap(timur_);
		 }
private: System::Void numericLVT_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra timur
					 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
					 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
					 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
 					 iLowS[timur] = Convert::ToInt16(numericLST->Value);
					 iHighS[timur] = Convert::ToInt16(numericHST->Value);
					 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
					 iHighV[timur] = Convert::ToInt16(numericHVT->Value);


					 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
					 //morphological opening (remove small objects from the foreground)
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./timur.bmp", timur_);
					 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
					 this->pictureBoxTimur->Image = MatToBitmap(timur_);
		 }
private: System::Void numericHVT_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra timur
					 cvtColor(src, timur_, cv::COLOR_BGR2HSV);
					 iLowH[timur] = Convert::ToInt16(numericLHT->Value);
					 iHighH[timur] = Convert::ToInt16(numericHHT->Value);
 					 iLowS[timur] = Convert::ToInt16(numericLST->Value);
					 iHighS[timur] = Convert::ToInt16(numericHST->Value);
					 iLowV[timur] = Convert::ToInt16(numericLVT->Value);
					 iHighV[timur] = Convert::ToInt16(numericHVT->Value);


					 inRange(timur_, Scalar(iLowH[timur], iLowS[timur], iLowV[timur]), Scalar(iHighH[timur], iHighS[timur], iHighV[timur]), timur_);
					 //morphological opening (remove small objects from the foreground)
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(timur_, timur_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./timur.bmp", timur_);
					 //this->pictureBoxTimur->ImageLocation = "./timur.bmp";
					 this->pictureBoxTimur->Image = MatToBitmap(timur_);
		 }
private: System::Void numericLHS_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra selatan
					 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
					 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
					 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
 					 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
					 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
					 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
					 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);


					 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
					 //morphological opening (remove small objects from the foreground)
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./selatan.bmp", selatan_);
					 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
					 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
		 }
private: System::Void numericHHS_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra selatan
					 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
					 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
					 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
 					 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
					 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
					 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
					 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);


					 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
					 //morphological opening (remove small objects from the foreground)
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./selatan.bmp", selatan_);
					 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
					 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
		 }
private: System::Void numericLSS_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra selatan
					 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
					 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
					 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
 					 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
					 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
					 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
					 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);


					 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
					 //morphological opening (remove small objects from the foreground)
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./selatan.bmp", selatan_);
					 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
					 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
		 }
private: System::Void numericHSS_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra selatan
					 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
					 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
					 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
 					 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
					 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
					 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
					 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);


					 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
					 //morphological opening (remove small objects from the foreground)
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./selatan.bmp", selatan_);
					 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
					 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
		 }
private: System::Void numericLVS_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra selatan
					 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
					 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
					 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
 					 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
					 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
					 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
					 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);


					 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
					 //morphological opening (remove small objects from the foreground)
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./selatan.bmp", selatan_);
					 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
					 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
		 }
private: System::Void numericHVS_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
			 //menampilkan citra selatan
					 cvtColor(src, selatan_, cv::COLOR_BGR2HSV);
					 iLowH[selatan] = Convert::ToInt16(numericLHS->Value);
					 iHighH[selatan] = Convert::ToInt16(numericHHS->Value);
 					 iLowS[selatan] = Convert::ToInt16(numericLSS->Value);
					 iHighS[selatan] = Convert::ToInt16(numericHSS->Value);
					 iLowV[selatan] = Convert::ToInt16(numericLVS->Value);
					 iHighV[selatan] = Convert::ToInt16(numericHVS->Value);


					 inRange(selatan_, Scalar(iLowH[selatan], iLowS[selatan], iLowV[selatan]), Scalar(iHighH[selatan], iHighS[selatan], iHighV[selatan]), selatan_);
					 //morphological opening (remove small objects from the foreground)
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //morphological closing (fill small holes in the foreground)
					 dilate(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 erode(selatan_, selatan_, getStructuringElement(MORPH_ELLIPSE, cv::Size(5, 5)));
					 
					 //imwrite("./selatan.bmp", selatan_);
					 //this->pictureBoxSelatan->ImageLocation = "./selatan.bmp";
					 this->pictureBoxSelatan->Image = MatToBitmap(selatan_);
		 }
private: System::Void buttonPos_Click(System::Object^  sender, System::EventArgs^  e) {
			 //posisi utara
			 dapatPosisi(utara_, posisi.x[utara], posisi.y[utara]);
			 this->labelPosUtaraX->Text = Convert::ToString(posisi.x[utara]);
			 this->labelPosUtaraY->Text = Convert::ToString(posisi.y[utara]);

			 //posisi selatan
			 dapatPosisi(selatan_, posisi.x[selatan], posisi.y[selatan]);
			 this->labelPosSelatanX->Text = Convert::ToString(posisi.x[selatan]);
			 this->labelPosSelatanY->Text = Convert::ToString(posisi.y[selatan]);

			 //posisi  timur
			 dapatPosisi(timur_, posisi.x[timur], posisi.y[timur]);
			 this->labelPosTimurX->Text = Convert::ToString(posisi.x[timur]);
			 this->labelPosTimurY->Text = Convert::ToString(posisi.y[timur]);

			 //posisi barat
			 dapatPosisi(barat_, posisi.x[barat], posisi.y[barat]);
			 this->labelPosBaratX->Text = Convert::ToString(posisi.x[barat]);
			 this->labelPosBaratY->Text = Convert::ToString(posisi.y[barat]);

			 //mencari koordinat x robot
			 /*
			 jarakHorzLing = sqrt(pow((posisi.x[barat]-posisi.x[timur]),2)+pow((posisi.y[barat]-posisi.y[timur]),2));
			 jarakHorzMob = sqrt(pow((posisi.x[barat]-(src.cols/2)),2)+pow((posisi.y[barat]-(src.rows/2)),2));
			 posX = jarakHorzLing  - (jarakHorzLing - jarakHorzMob);
			 */
			 //mencari koordinat y robot
			 /*
			 jarakVertLing = sqrt(pow((posisi.x[utara]-posisi.x[selatan]),2)+pow((posisi.y[utara]-posisi.y[selatan]),2));
			 jarakVertMob = sqrt(pow((posisi.x[utara]-(src.cols/2)),2)+pow((posisi.y[utara]-(src.rows/2)),2));
			 posY = jarakVertLing  - (jarakVertLing - jarakVertMob);
			 */

			 
			 jarakHorzLing = sqrt(pow((posisi.x[barat]-posisi.x[timur]),2)+pow((posisi.y[barat]-posisi.y[timur]),2));
			 jarakVertLing = sqrt(pow((posisi.x[utara]-posisi.x[selatan]),2)+pow((posisi.y[utara]-posisi.y[selatan]),2));
			 

			 double sumMarkY=0, sumMarkX=0, averageMarkY, averageMarkX;
			 for(int i=0;i<4;i++)
			 {
				 sumMarkY+=posisi.y[i];
				 sumMarkX+=posisi.x[i];
			 }
			 averageMarkY = sumMarkY/4;
			 averageMarkX = sumMarkX/4;

			 centerMarkX = averageMarkX;
			 centerMarkY = averageMarkY;

			 this->LMX->Text = Convert::ToString(centerMarkX);
			 this->LMY->Text = Convert::ToString(centerMarkY);

			 posX = centerImX - centerMarkX;
			 posY = centerMarkY - centerImY;

			 
			 this->labelPosX->Text = Convert::ToString(posX);
			 this->labelPosY->Text = Convert::ToString(posY);

			 double Xcm, Ycm;
			 Xcm = posX/jarakHorzLing*(Convert::ToDouble(numericScale->Value));
			 Ycm = posY/jarakVertLing*(Convert::ToDouble(numericScale->Value));
			 this->labelXcm->Text = Convert::ToString(Xcm);
			 this->labelYcm->Text = Convert::ToString(Ycm);
			 
		 }
};
}
