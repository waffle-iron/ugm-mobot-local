#pragma once
//Memasukkan pustaka yang dibutuhkan
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string>
#include "MyForm.h"

#define utara		0
#define selatan		1
#define timur		2
#define barat		3
#define baris		0
#define kolom		1

using namespace cv;
using namespace std;

extern cv::Mat src, utara_, selatan_, timur_, barat_;
extern int dialogStatus;

//untuk filter
extern int iLowH[4];
extern int iHighH[4];

extern int iLowS[4];
extern int iHighS[4];

extern int iLowV[4];
extern int iHighV[4];

#ifndef _CVTOBITMAP_H_
#define _CVTOBITMAP_H_

System::Drawing::Bitmap^ MatToBitmap(const cv::Mat& img)
{
	cv::Mat img2;
	if (img.type() == CV_8UC3) 
		img2 = img;
	else if (img.type() == CV_8UC1) 
		cv::cvtColor(img, img2, cv::COLOR_GRAY2RGB);
	else
		throw gcnew System::NotSupportedException(
			"Only images of type CV_8UC3 are supported for conversion to Bitmap");

	//create the bitmap and get the pointer to the data
	System::Drawing::Imaging::PixelFormat fmt(System::Drawing::Imaging::PixelFormat::Format24bppRgb);
	System::Drawing::Bitmap ^bmpimg = gcnew System::Drawing::Bitmap(img2.cols, img2.rows, fmt);
	System::Drawing::Imaging::BitmapData ^data = bmpimg->LockBits(System::Drawing::Rectangle(0, 0, img2.cols, img2.rows), 
		System::Drawing::Imaging::ImageLockMode::WriteOnly, fmt);

	char *dstData = reinterpret_cast<char*>(data->Scan0.ToPointer());
	unsigned char *srcData = img2.data;

	for (int row = 0; row < data->Height; ++row) 
		memcpy(reinterpret_cast<void*>(&dstData[row*data->Stride]), reinterpret_cast<void*>(&srcData[row*img2.step]), 
			img2.cols*img2.channels());

	bmpimg->UnlockBits(data);
	return bmpimg;
}

#endif /*_CVTOBITMAP_H_*/

void dapatPosisi(cv::Mat &citraAbu, int &posX, int &posY)
{
	int sums[2]={0,0}, counts[2]={0,0};
	for(int i = 0; i<2; i++)
	{
		 sums[i] = 0;
		 counts[i] = 0;
	}

	for (int i=0; i<citraAbu.cols; i++)
	{
		for (int j=0; j<citraAbu.rows;j++)
		{
			int temp = citraAbu.at<uchar>(j,i);
			if(temp==255)
			{
				sums[baris]+=j;
				sums[kolom]+=i;
				counts[baris]++;
				counts[kolom]++;
			}
		} 
	}

	posY = sums[baris] / counts[baris];
	posX = sums[kolom] / counts[kolom];
}