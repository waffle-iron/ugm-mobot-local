// Nama Form
#include "MyForm.h"

// Pustaka yang diperlukan
#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string>

#define utara		0
#define selatan		1
#define timur		2
#define barat		3
#define baris		0
#define kolom		1

using namespace std;
using namespace cv;
using namespace System;
using namespace System::Windows::Forms;

/* Mendifinisikan Variabel Global */
// openDialogBox
int dialogStatus = 0;
// openCV variables
cv::Mat src, utara_, selatan_, timur_, barat_;

//untuk filter
int iLowH[4] = {0, 0, 0, 0};
int iHighH[4] = {179, 179, 179, 179};

int iLowS[4] = {0, 0, 0, 0};
int iHighS[4] = {255, 255, 255, 255};

int iLowV[4] = {0, 0, 0, 0};
int iHighV[4] = {255, 255, 255, 255};




/* Mendifiniskan Variabel Global Selesai */

[STAThreadAttribute]
void Main(array<System::String^>^ args)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	// Project Name and Form Type
	LokalisasiInputCitra::MyForm form;
	// Menjalankan form
	Application::Run(%form);

}